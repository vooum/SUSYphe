#!/usr/bin/env python2

import os, sys, shutil
import pandas as pd

pwd = os.path.abspath(os.path.dirname(__file__))
path = "/media/tev-htu/DATA/zd/gnmssm"

def pre_calc(no):
   os.system("rm {}/prospino_main.f90".format(pwd))
   os.system("rm {}/prospino.in.les_houches".format(pwd))
   data = pd.read_csv("{}/slhaReaderOutPut.csv".format(path))
   Index = data['Index'].loc[no-1]
   with open("{}/InputsForProspino/ProspinoIn_{}.txt".format(path, str(Index)), 'r') as f2:
       with open("{}/prospino.in.les_houches".format(pwd), 'w') as f3:
           f3.write(f2.read())
   return Index

def calc(proc_path):      
   os.system("cp {}/proc_* {}/prospino_main.f90".format(proc_path, pwd))
   os.chdir(pwd)
   os.system("make > s.txt")
   os.system("./prospino_2.run > a.txt")
   with open("{}/prospino.dat".format(pwd), 'r') as f33:
       line = f33.readline()
       result = float(line.split()[-1])
       #print(result)
   os.chdir(pwd)
   return result

if __name__ == "__main__":
   inputfile = sys.argv[1]
   with open(inputfile, 'r') as f:
       no = int(round(float(f.readline())))
   sumcs13 = 0.
   Index = pre_calc(no)
   result = [str(Index)]
   for i in range(32):
      n = i + 1
      path = "{}/process/proc_{}".format(pwd, str(n))
      #if rank==i:
      print(i)
      cs13 = calc(path)
      result.append(str(cs13))
      sumcs13 += cs13
      print(result)
   result.append(str(sumcs13))
   print(result)
   data = [result]
   df = pd.DataFrame(data,columns=['Index', 'c1barc2_pb', 'c1barn2_pb', 'c1barn3_pb', 'c1barn4_pb', 'c1barn5_pb', 'c1c1bar_pb', 'c1c2bar_pb', 'c1n2_pb', 'c1n3_pb', 'c1n4_pb', 'c1n5_pb', 'c2barn2_pb', 'c2barn3_pb', 'c2barn4_pb', 'c2barn5_pb', 'c2c2bar_pb', 'c2n2_pb', 'c2n3_pb', 'c2n4_pb', 'c2n5_pb', 'n2n2_pb', 'n2n3_pb', 'n2n4_pb', 'n2n5_pb', 'n3n3_pb', 'n3n4_pb', 'n3n5_pb', 'n4n4_pb', 'n4n5_pb', 'n5n5_pb', 'smulsmul_pb', 'smursmur_pb', 'sumcs13_pb'])
   #df.to_csv("{}/process/cs13.csv".format(pwd), index=False)
   df.to_csv("{}/process/cs13.csv".format(pwd), sep=',', mode='a', header=True, index=None)
